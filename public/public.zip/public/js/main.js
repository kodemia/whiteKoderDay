// Firebase
// Conecciones
// var db = firebase.database();
// var storage  = firebase.storage();
//
// // Referencias
// var housingRef = db.ref('housing/');
// var storageRef = storage.ref();
